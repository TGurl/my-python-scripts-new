#!/usr/bin/env python
import os
import sys
import shutil
import random
import string

from pytube import Playlist, YouTube

VIDEO_DIR = 'videos'
IMAGE_DIR = 'images'

def banner(title=''):
    os.system('clear')
    print("SPLITr - Copyright 2024 Transgirl")
    if title:
        print(title)

def show_usage():
    banner()
    print("A simple script to convert video files to images.", end='\n\n')
    print("Usage:")
    print("     splitr -p <YouTube playlist id>")
    print("     splitr -v <YouTube video id>", end='\n\n')
    print("Examples:")
    print("     splitr -p PL6wsNKTwen-fotycYeD_YYojmHj0SMLPI")
    print("     splitr -v b-jMVx0tttY", end='\n\n')
    sys.exit()

def preflight_checklist():
    folders = [VIDEO_DIR, IMAGE_DIR]
    for folder in folders:
        if not os.path.exists(folder):
            os.mkdir(folder)
        else:
            shutil.rmtree(folder)
            os.mkdir(folder)


def process_video(video_id):
    yt_url = f"https://www.youtube.com/watch?v={video_id}"
    video = YouTube(yt_url)
    video_filename = video.channel_id.replace(' ', '')
    idx = ''.join(random.choices(string.digits, k=4))

    banner()
    print(f"> Downloading {video.title}")
    print(f"> Saving as {video_filename}")
    ytdlp = "yt-dlp --quiet --progress --write-thumbnail"
    ytdlp += f" -o 'videos/{video_filename}{idx:04}.%(ext)s' {yt_url}"
    os.system(ytdlp)

def process_playlist(playlist_id):
    yt_url = f"https://www.youtube.com/playlist?list={playlist_id}"
    playlist = Playlist(yt_url)
    video_filename = playlist.title.lower().replace(' ', '')
    total = len(playlist.video_urls) - 1

    for idx, url in enumerate(playlist.video_urls):
        banner(title=f"Title: {playlist.title}")

        video = YouTube(url)
        print(f"> Downloading {idx} / {total}: {video.title}")
        ytdlp = "yt-dlp --quiet --progress --write-thumbnail"
        ytdlp += f" -o 'videos/{video_filename}{idx:04}.%(ext)s' {url}"
        os.system(ytdlp)

def move_thumbnails_to_images():
    banner(title=f'Moving thumbnails to {IMAGE_DIR}')

    allowed = ['.webp', '.png', '.jpg', '.jpeg']
    for item in os.scandir(VIDEO_DIR):
        _, ext = os.path.splitext(item.name)
        if ext.lower() in allowed:
            origin = os.path.join(VIDEO_DIR, item.name)
            destination = os.path.join(IMAGE_DIR, item.name)
            shutil.move(origin, destination)


def process_videos():
    all_videos = []
    allowed = ['.webm', '.mp4', '.mkv']

    # -- collect all the videos
    for item in os.scandir(VIDEO_DIR):
        _, ext = os.path.splitext(item.name)
        if ext.lower() in allowed:
            all_videos.append(item.name)
    all_videos.sort()

    total = len(all_videos) - 1

    # -- itterate over videos and save screengrabs

    for idx, video in enumerate(all_videos):
        banner(title='Processing the videos')
        print(f"Working on video {idx:3} out of {total}")

        image_name, _ = os.path.splitext(video)
        imgpath = os.path.join(IMAGE_DIR, f"{image_name}%04d.png")

        path = os.path.join(VIDEO_DIR, video)
        ffmpeg = "ffmpeg -hide_banner -loglevel error -stats -y "
        ffmpeg += f"-i {path} -vf fps=1 {imgpath}"
        os.system(ffmpeg)


def main(args):
    video_id = ''
    playlist_id = ''
    
    if '-v' in args and '-p' in args:
        show_usage()
    elif '-v' in args:
        index = args.index('-v') + 1
        video_id = args[index]
    elif '-p' in args:
        index = args.index('-p') + 1
        playlist_id = args[index]
    else:
        show_usage()

    preflight_checklist()
    if playlist_id:
        process_playlist(playlist_id)
    
    if video_id:
        process_video(video_id)

    move_thumbnails_to_images()
    process_videos()

if __name__ == "__main__":
    if len(sys.argv) <= 1:
        show_usage()
    main(sys.argv)
