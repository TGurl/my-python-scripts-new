#!/usr/bin/env python
import os
import re
import sys
import shutil
import string
import random
import subprocess
import readchar

from pytube import YouTube, Playlist
from datetime import timedelta
from time import sleep


class MyYouTubeDownloader:
    def __init__(self):
        self.video_id = ''
        self.playlist_id = ''
        self.video_length = ''
        self.external_list = ''
        self.processing_list = False
        self.video_folder = 'videos'
        self.image_folder = 'images'
        self.keep_folder = 'keep'
        self.youtube_playlist_url = 'https://www.youtube.com/playlist?list='
        self.youtube_video_url = 'https://www.youtube.com/watch?v='
        self.screenshot_extension = 'png'

    def generate_random_string(self, length=4) -> str:
        characters = string.digits + string.ascii_letters
        return ''.join(random.choices(characters, k=length))

    def remove_spaces(self, mystring='') -> str:
        return mystring.replace(' ', '')

    def preflight_check(self):
        if not os.path.exists(self.video_folder):
            os.mkdir(self.video_folder)
            # shutil.rmtree(self.video_folder)

        if not os.path.exists(self.image_folder):
            os.mkdir(self.image_folder)
            # shutil.rmtree(self.image_folder)

  
    def clean_up(self):
        if os.path.exists(self.video_folder):
            shutil.rmtree(self.video_folder)

        if os.path.exists(self.image_folder):
            shutil.rmtree(self.image_folder)

        self.banner()
        if not self.processing_list:
            self.step_message("All done. Have fun editing the b(.)(.)bs...")
        else:
            os.remove(self.external_list)
            self.step_message("We're all done.You did good, girl.")
        sys.exit()

    def banner(self, clear_screen=True):
        if clear_screen:
            os.system('clear')
        print("SPLITr - A simple script to split YouTube videos into images")
        print("Copyright (C) 2024 Transgirl Coding Studios", end='\n\n')

    def show_usage(self, error=''):
        self.banner()
        if error:
            print(f"Error! {error}", end='\n\n')
        print("Usage:")
        print("    splitr <option> <YouTube ID>", end='\n\n')
        print("Options:")
        print("    -p   Download videos from playlist.")
        print("    -v   Download a single video")
        print("    -j   Save screengraps as JPEG", end='\n\n')
        print("Examples:")
        print("    splitr -p -j PLf7cBO2Vfd3XcFmnYWLcwXJfy02hyYpnh")
        print("    splitr -v -j b-jMVx0tttY")
        print("    splitr -e (Show an example)", end='\n\n')
        sys.exit()

    def step_message(self, message):
        print(f"- {message}")

    def construct_youtube_url(self, url):
        if self.playlist_id and not self.youtube_playlist_url in url:
            full_url = f"{self.youtube_playlist_url}{self.playlist_id}"
        elif self.video_id and not self.youtube_video_url in url:
            full_url = f"{self.youtube_video_url}{self.video_id}"
        else:
            full_url = url
        return full_url

    def get_youtube_extension(self, url):
        filetype = subprocess.getoutput('yt-dlp --no-warnings --print filename -o "%(ext)s" ' + url)
        if 'Skipping player responses from android' in filetype:
            filetype = 'mkv?'
        filetype = re.escape(filetype)
        return filetype

    def preview_video(self):
        self.banner()
        self.step_message("Starting preview")
        url = self.construct_youtube_url(self.video_id)
        mpv = f"mpv {url}"
        os.system(mpv)

    def download_video(self):
        self.banner()
        self.step_message("Collecting information...")
        url = self.construct_youtube_url(self.video_id)
        video = YouTube(url)
        
        title = video.title
        if len(title) > 40:
            title = title[:36] + '....'

        video_extension = self.get_youtube_extension(url)
        random_string = self.generate_random_string(length=16)
        filename = random_string + "." + video_extension
        fullpath = os.path.join(self.video_folder, filename)

        # -- fetch length of video
        length = str(timedelta(seconds=video.length))
        first_part = length.split(':')[0]
        self.video_length = '0' + length if len(first_part) == 1 else length

        self.clear_line()
        self.step_message(f"Channel name : {video.author}")
        self.step_message(f"Video title  : {title}")
        self.step_message(f"Video length : {self.video_length}")
        self.step_message(f"Saving as    : {random_string}")
        self.step_message(f"Video type   : {video_extension}")
        # self.step_message(f"Saving as    : {fullpath}")
        print()
        if os.path.exists(fullpath):
            print(f"The video '{fullpath}' has been downloaded already.")
            sleep(1.2)
            print("")
        else:
            print("System output:")
            ytdlp = "yt-dlp --quiet --progress --write-thumbnail --no-warnings "
            ytdlp += f'-o "{fullpath}" {url}'
            os.system(ytdlp)
            print("")

        # -- move thumbnail to images folder
        allowed = ['.webp', '.png']
        for item in os.scandir(self.video_folder):
            _, ext = os.path.splitext(item.name)
            if ext in allowed:
                destination = os.path.join(self.image_folder, item.name)
                shutil.move(item.path, destination)
        # -- done moving thumbnails

    def process_playlist(self):
        url = self.construct_youtube_url(self.playlist_id)
        self.preview_video()
        self.playlist_id = ''
        playlist = Playlist(url)
        total_videos = len(playlist.video_urls)

        self.step_message(f"Processing : {playlist.title}")
        for idx, video_url in enumerate(playlist.video_urls, start=1):
            self.banner()
            self.step_message(f"Parsing {idx:4} out of {total_videos:4} videos")
            self.video_id = video_url
            self.download_video()

    def show_example(self):
        self.video_id = 'ObEtRpDb9mA'
        self.banner()
        self.step_message("This is an example of how this script works.")
        self.preview_video()
        self.download_video()
        self.generate_screengrabs()
        self.image_viewer()
        self.clean_up()


    def generate_screengrabs(self):
        # -- collect all videos
        allowed = ['.webm', '.mp4', '.mkv']
        video_list = []
        for item in os.scandir(self.video_folder):
            _, extension = os.path.splitext(item.name)
            if extension in allowed:
                video_list.append(item.name)
        video_list.sort()
        total = len(video_list)

        if total == 0:
            self.step_message("No videos found.")
            sys.exit()

        # -- itterate video_list and generate screengrabs
        for idx, video in enumerate(video_list, start=1):
            self.banner()
            # self.step_message("Generating screengrabs")
            if total > 1:
                self.step_message(f"Processing video {idx:2} out of {total:2}")

            video_path = os.path.join(self.video_folder, video)
            image_path = os.path.join(self.image_folder, video.split('.')[0])
            self.step_message(f"Video     : {video_path}")
            self.step_message(f"Length    : {self.video_length}")
            self.step_message(f"Extension : {self.screenshot_extension}")
            ffmpeg = "ffmpeg -y -hide_banner -loglevel error -stats "
            ffmpeg += f"-i {video_path} -vf fps=1 {image_path}_%04d.{self.screenshot_extension}"
            print()
            print("System output:")
            os.system(ffmpeg)

    def image_viewer(self):
        if not os.path.exists(self.keep_folder):
            os.mkdir(self.keep_folder)

        allowed = ['.webp', '.png', '.jpg']
        image_list = []
        msg = "Keep this image? y/n/q "

        for item in os.scandir(self.image_folder):
            _, ext = os.path.splitext(item.name)
            if ext in allowed:
                image_list.append(item.name)
        image_list.sort()
        total = len(image_list)

        for idx, image in enumerate(image_list, start=1):
            path = os.path.join(self.image_folder, image)
            keep = os.path.join(self.keep_folder, image)
            percent = (100 * idx) // total

            # timg = f"timg -g32x {path}"
            timg = f"timg -U {path}"

            os.system('clear')
            os.system(timg)
            
            self.step_message(f"Showing {idx} out of {total} [{percent:3}% done]")
            
            keypressed = False
            while not keypressed:
                print(msg, end="", flush=True)
                key = readchar.readchar().lower()
            
                if key == 'q':
                    print("")
                    self.clean_up()
                    sys.exit()
                elif key == 'n':
                    os.remove(path)
                    keypressed = True
                elif key == 'y':
                    shutil.move(path, keep)
                    keypressed = True
                else:
                    print("")
                    print("That's the wrong key, girl.")
                    sleep(1.2)
                    for _ in range(2):
                        self.clear_line()

    def process_list(self):
        self.processing_list = True
        if not os.path.exists(self.external_list):
            print(f"Could not find '{self.external_list}'. Did you even make one, you stupid cow?")
            sys.exit()

        with open(self.external_list, 'r', encoding='utf-8') as file:
            data = file.readlines()

        for line in data:
            self.video_id = line.split('=')[1].strip()
            self.banner()
            self.preview_video()
            self.download_video()
        
        self.generate_screengrabs()
        self.image_viewer()
        self.clean_up()
        self.banner()
    

    def parse_args(self, args):
        if '-j' in args:
            self.screenshot_extension = 'jpg'

        if '-v' in args and '-p' in args and '-e' in args:
            self.show_usage(error='You cannot issue -v, -p  and -e at the same time.')
            sys.exit()
        elif '-v' in args:
            self.video_id = args[args.index('-v') + 1]
            self.banner()
            self.preview_video()
            self.download_video()
        elif '-p' in args:
            self.playlist_id = args[args.index('-p') + 1]
            self.process_playlist()
        elif '-e' in args:
            self.show_example()
        elif '-l' in args:
            self.external_list = args[args.index('-l') + 1]
            self.process_list()
        else:
            self.show_usage(error='Wrong arguments passed.')
            sys.exit()
    
    def main(self, args):
        self.preflight_check()
        self.parse_args(args)
        self.generate_screengrabs()
        self.image_viewer()
        self.clean_up()

    def clear_line(self):
        print('\033[1A', end='\x1b[2K')

if __name__ == "__main__":
    app = MyYouTubeDownloader()

    if len(sys.argv) <= 1:
        app.show_usage(error="No arguments passed")
    else:
        app.main(sys.argv)

